const express = require("express");
const mysql = require("mysql2");
const cors = require("cors");
const users = [];
require("dotenv").config();

const app = express();
app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
    res.send("Welcome to backend api server");
});

app.get("/favicon.ico", (req, res) => res.status(204).end());

const db = mysql.createConnection({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
});

db.connect((err) => {
    if (err) {
        console.error("Database connection failed:", err.message);
        return;
    }
    console.log("Connected to the MySQL database!");
});


// handle users api....
app.post('/api/users', (req, res) => {
    const { name, email, tel, password } = req.body;

    // Check user already exists in the database.............................
    const queryCheck = "SELECT * FROM users WHERE email = ?";
    db.query(queryCheck, [email], (err, results) => {
        if (err) {
            console.error("Error querying the database:", err);
            return res.status(500).json({ message: "Internal server error" });
        }
        if (results.length > 0) {
            return res.status(409).json({ message: "User already exists" });
        }

        // Insert user into the database..........................
        const queryInsert = "INSERT INTO users (name, email, tel, password) VALUES (?, ?, ?, ?)";
        db.query(queryInsert, [name, email, tel, password], (err) => {
            if (err) {
                console.error("Erro inserting into the database", err);
                return res.status(500).json({ message: "Internal server error" });
            }
            res.status(201).json({ message: "User registered successfully !" });
        });
    });
});

  
// handle login api....
app.post('/api/login', (req, res) => {
    const { email, password } = req.body;

    const query = "SELECT * FROM users WHERE email = ? AND password = ?";
    db.query(query, [email, password], (err, results) => {
        if (err) {
            console.error("Error querying the database", err);
            return res.status(500).json({ message: "Internal server error" });
        }
        if (results.length > 0) {
            const user = results[0]; // user matching
            res.status(200).json({ name: user.name, email: user.email, tel: user.tel });
        } else {
            res.status(401).json({ message: "Invalid email or password" });
        }
    });
});

// Start The Server...............

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server is running on the port ${PORT}`);
});

