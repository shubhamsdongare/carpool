import React from "react";

const ViewOfferedRides = ({ offeredRides, onCancelOfferedRide }) => {
  return (
    <div className="bg-gray-50 min-h-screen p-8 flex flex-col items-center">
      <h2 className="text-2xl font-bold mt-16 mb-8 text-center">
        Your Offered Rides will appear here.
      </h2>
      {offeredRides.length > 0 ? (
        <ul className="list-none w-full max-w-xl space-y-4">
          {offeredRides.map((ride, index) => (
            <li key={index} className="p-6 bg-white rounded-lg shadow-md">
              <div className="text-lg font-semibold text-gray-800 mb-2">
                Offered Ride {index + 1}
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>
                  <strong>From:</strong> {ride.pickup}
                </p>
                <p>
                  <strong>To:</strong> {ride.drop}
                </p>
                <p>
                  <strong>Date:</strong> {ride.date}
                </p>
                <p>
                  <strong>Seats Available:</strong> {ride.availableSeats}
                </p>
              </div>
              <button
                onClick={() => onCancelOfferedRide(index)}
                className="mt-4 bg-red-600 text-white py-2 px-4 rounded hover:bg-red-500"
              >
                Cancel Ride
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-600 mt-8">No offered rides available.</p>
      )}
    </div>
  );
};

export default ViewOfferedRides;
