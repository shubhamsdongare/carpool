import React from "react";

const ViewBookedRides = ({ bookedRides, onCancelRide }) => {
  return (
    <div className="bg- min-h-screen p-8 flex flex-col items-center">
      <h2 className="text-2xl font-bold mt-16 mb-8 text-center">
        Your future travel plans will appear here.
      </h2>
      {bookedRides.length > 0 ? (
        <ul className="list-none w-full max-w-xl space-y-4">
          {bookedRides.map((ride, index) => (
            <li key={index} className="p-6 bg-white rounded-lg shadow-md">
              <div className="text-lg font-semibold text-gray-800 mb-2">
                Ride {index + 1}
              </div>
              <div className="text-sm text-gray-600 space-y-1">
                <p>
                  <strong>Pick-up:</strong> {ride.pickup}
                </p>
                <p>
                  <strong>Drop:</strong> {ride.drop}
                </p>
                <p>
                  <strong>Date:</strong> {ride.date}
                </p>
                <p>
                  <strong>Passengers:</strong> {ride.passengers}
                </p>
              </div>
              <button
                onClick={() => onCancelRide(index)}
                className="mt-4 bg-red-600 text-white py-2 px-4 rounded hover:bg-red-500"
              >
                Cancel Ride
              </button>
            </li>
          ))}
        </ul>
      ) : (
        <p className="text-gray-600 mt-8">No booked rides found.</p>
      )}
    </div>
  );
};

export default ViewBookedRides;
