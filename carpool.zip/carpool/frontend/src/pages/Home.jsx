import React, { useState } from "react"; 
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarDays, faUser, faTags, faAddressCard, faPaperPlane } from '@fortawesome/free-solid-svg-icons';
import SearchRideForm from "../components/SearchRideForm";
import BookingForm from "../components/BookingForm";

const Home = ({ rideOffers, user, onBookRide }) => {
  const [showRides, setShowRides] = useState(false);
  const [filteredRides, setFilteredRides] = useState([]);
  const [showBookingForm, setShowBookingForm] = useState(false);
  const [selectedRide, setSelectedRide] = useState(null);

  const handleFormSubmit = (formData) => {
    // Filter for ride search
    const filtered = rideOffers.filter((ride) => {
      return (
        (ride.pickup.toLowerCase().includes(formData.leavingFrom.toLowerCase()) || !formData.leavingFrom) &&
        (ride.drop.toLowerCase().includes(formData.goingTo.toLowerCase()) || !formData.goingTo) &&
        (ride.date === formData.date || !formData.date) &&
        (ride.passengers >= parseInt(formData.passengers) || !formData.passengers)
      );
    });

    setFilteredRides(filtered);
    setShowRides(true);
  };

  const handleBookRide = (ride) => {
    if (!user) {
      alert("You must be logged in to book a ride."); // Alert if user is not logged in
      return;
    }
    setSelectedRide(ride); // Set selected ride for booking
    setShowBookingForm(true); // Show booking form
  };

  const handleBookingConfirm = () => {
    if (selectedRide) {
      onBookRide(selectedRide); // .........................onBookRide prop to handle booking
      console.log(`Ride booked: ${selectedRide.carName}`); // ...............
    }
    setShowBookingForm(false); // Hide the BookingForm
  };

  return (
    <>
      {/* Image */}
      <div>
        <img src="/first.jpg" alt="Banner" className="w-full h-96 object-cover mt-16" />
      </div>

      {/* Search Form */}
      <SearchRideForm onSubmit={handleFormSubmit} />

      {/* Available Rides */}
      {showRides && (
        <div className="mt-8">
          <h2 className="text-xl font-bold mb-4">Available Rides</h2>
          {filteredRides.length > 0 ? (
            filteredRides.map((ride, index) => (
              <div key={index} className="mb-4 p-4 border rounded shadow">
                <p><strong>Pick-up Location:</strong> {ride.pickup}</p>
                <p><strong>Drop Location:</strong> {ride.drop}</p>
                <p><strong>Date:</strong> {ride.date}</p>
                <p><strong>Time:</strong> {ride.time}</p>
                <p><strong>Passengers:</strong> {ride.passengers}</p>
                <p><strong>Car:</strong> {ride.carName}</p>
                <button
                  className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded mt-4"
                  onClick={() => handleBookRide(ride)}
                >
                  Book Ride
                </button>
              </div>
            ))
          ) : (
            <p>No rides found.</p>
          )}
        </div>
      )}

      {/* Booking Form */}
      {showBookingForm && selectedRide && (
        <BookingForm 
          ride={selectedRide} 
          onConfirm={handleBookingConfirm} // Confirm booking
          onCancel={() => setShowBookingForm(false)}
        />
      )}

      {/* Booking Form */}
      {/* {showBookingForm && selectedRide && (
        <BookingForm ride={selectedRide} onConfirm={handleBookingConfirm} /> // Pass selected ride and confirmation logic
      )} */}
      {/* Available Rides */}
      {/* <div className="mt-8">
        <h2 className="text-xl font-bold mb-4">Available Rides</h2>
        {filteredRides.length > 0 ? (
          filteredRides.map((ride, index) => (
            <div key={index} className="mb-4 p-4 border rounded shadow">
              <p><strong>Pick-up Location:</strong> {ride.pickup}</p>
              <p><strong>Drop Location:</strong> {ride.drop}</p>
              <p><strong>Date:</strong> {ride.date}</p>
              <p><strong>Passengers:</strong> {ride.passengers}</p>
              <p><strong>Car:</strong> {ride.carName}</p>
            </div>
          ))
        ) : (
          <p>No rides found.</p>
        )}
      </div> */}

      <div className="flex flex-col md:flex-row justify-evenly items-start md:space-x-10 mx-4 md:mx-60 mt-10">
        <div className="w-full md:w-1/3 text-center flex flex-col items-center mb-6 md:mb-0">
          <div>
            <FontAwesomeIcon
              icon={faTags}
              className="w-7 h-7 text-gray-600"
            />
          </div>
          <h2 className="font-semibold text-base text-gray-700 mt-4">
            Your pick of rides at low prices
          </h2>
          <span className="text-sm text-gray-500 mt-2">
            No matter where you’re going, by bus or carpool, find the perfect ride from our wide range of destinations and routes at low prices.
          </span>
        </div>

        <div className="w-full md:w-1/3 text-center flex flex-col items-center mb-6 md:mb-0">
          <div>
            <FontAwesomeIcon
              icon={faAddressCard}
              className="w-7 h-7 text-gray-600"
            />
          </div>
          <h2 className="font-semibold text-base text-gray-700 mt-4">
            Trust who you travel with
          </h2>
          <span className="text-sm text-gray-500 mt-2">
            We take the time to get to know each of our members and bus partners. We check reviews, profiles and IDs, so you know who you’re travelling with and can book your ride at ease on our secure platform.
          </span>
        </div>

        <div className="w-full md:w-1/3 text-center flex flex-col items-center">
          <div>
            <FontAwesomeIcon
              icon={faPaperPlane}
              className="w-7 h-7 text-gray-600"
            />
          </div>
          <h2 className="font-semibold text-base text-gray-700 mt-4">
            Scroll, click, tap and go!
          </h2>
          <span className="text-sm text-gray-500 mt-2">
            Booking a ride has never been easier! Thanks to our simple app powered by great technology, you can book a ride close to you in just minutes.
          </span>
        </div>
      </div>

      {/* Scamm */}
      <div className="bg-blue-700 h-auto md:h-[400px] mt-8 flex flex-col md:flex-row">
        <div className="flex justify-center md:justify-start">
          <img src="/second.png" alt="Scamm" className="w-full px lg:mx-40 md:w-[600px] h-auto md:h-[400px]" />
        </div>

        <div className="flex items-center justify-center mt-6 md:mt-0 md:ml-10 flex-col flex-grow">
          <h2 className="text-white text-center font-bold text-3xl w-10/12 md:w-1/2">
            Help us keep you safe from scams
          </h2>

          <h1 className="text-base text-white font-semibold mt-6 md:mt-10 w-10/12 md:w-1/2">
            At our carpooling app, we're working hard to make our platform as secure as it can be. But when scams do happen, we want you to know exactly how to avoid and report them. Follow our tips to help us keep you safe.
          </h1>

          <button className="px-3 py-2 rounded-3xl mt-5 text-blue-700 hover:bg-slate-200 font-bold bg-white">
            Learn more
          </button>
        </div>
      </div>

      {/* Drive Together */}
      <div className="flex flex-col md:flex-row mt-16 md:pr-48">
        <div className="flex items-start justify-center mx-6 md:mx-64 flex-col flex-grow">
          <h2 className="text-black text-center font-bold text-3xl">Driving in your car soon?</h2>

          <h1 className="text-base text-black font-semibold mt-6 w-full">
            Drivers, great news: your good habits are being rewarded! Benefit from the Carpool Bonus by carpooling. See eligibility conditions.
          </h1>

          <button className="px-5 py-3 mt-8 md:ml-28 rounded-3xl text-white hover:bg-blue-600 font-bold bg-blue-700">
            Offer Ride
          </button>
        </div>

        <div className="flex justify-center mt-6 md:mt-0">
          <img src="/third.jpg" alt="cargrp" className="w-full md:w-[600px] h-auto md:h-[300px]" />
        </div>
      </div>

      {/* Help Center */}
      <div className="text-start mt-10 pb-8 bg-gray-200">
        <h2 className="font-bold text-4xl pt-8 text-gray-700 text-center">Help Center</h2>

        <div className="flex flex-col lg:flex-row lg:justify-between lg:mx-48 lg:gap-20 mt-8">
          <div className="w-full lg:w-1/2 px-4 lg:px-0">
            <h3 className="font-semibold text-lg text-gray-600">How do I start carpooling?</h3>
            <p className="text-sm text-gray-500 pl-2 mt-2">
              Carpooling with this web-app is super easy and free! Simply sign up for an account and tell us some basic details about yourself. Once you have an account, you can start booking or publishing rides directly on our app or website.
            </p>
            <div className="w-auto h-px bg-black mt-8 lg:hidden"></div>
          </div>

          <div className="w-full lg:w-1/2 px-4 lg:px-0 mt-6 lg:mt-0">
            <h3 className="font-semibold text-lg text-gray-600">How do I cancel my carpool ride?</h3>
            <p className="text-sm text-gray-500 pl-2 mt-2">
            If you have a change of plans, you can always cancel your carpool ride from the ‘Your rides’ section of our app. The sooner you cancel, the better. That way the driver has time to accept new passengers. The amount of your refund will depend on how far in advance you cancel. If you cancel more than 24 hours before departure, for example, you’ll receive a full refund, excluding the service fee.
            </p>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row lg:justify-between lg:mx-48 lg:gap-20 mt-8">
          <div className="w-full lg:w-1/2 px-4 lg:px-0">
            <h3 className="font-semibold text-lg text-gray-600">How do I book a carpool ride?</h3>
            <p className="text-sm text-gray-500 pl-2 mt-2">
            You can book a carpool ride on our mobile app, or on carpool.in. Simply search for your destination, choose the date you want to travel and pick the carpool that suits you best! Some rides can be booked instantly, while other rides require manual approval from the driver. Either way, booking a carpool ride is fast, simple and easy.
            </p>
            <div className="w-auto h-px bg-black mt-8 lg:hidden"></div>
          </div>
          
          <div className="w-full lg:w-1/2 px-4 lg:px-0 mt-6 lg:mt-0">
            <h3 className="font-semibold text-lg text-gray-600">How do I know if my ride is safe?</h3>
            <p className="text-sm text-gray-500 pl-2 mt-2">
              Our app takes security seriously. All users are vetted before being allowed to book or publish rides. You can view ratings and reviews of other users to help you decide who to travel with. Additionally, we encourage users to report suspicious activity.
            </p>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
