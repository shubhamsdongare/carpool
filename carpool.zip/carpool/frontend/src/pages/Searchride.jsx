import React from 'react';

const SearchRide = () => {
  return (
    <div>
      <h1>Search for a Ride</h1>
      
    </div>
  );
};

export default SearchRide;
