import React from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarDays, faUser, faCar, faBolt, faMessage, faShield } from '@fortawesome/free-solid-svg-icons';
import OfferRideForm from '../components/OfferRideForm';

const Offerride = ({ addRideOffer, isLoggedIn }) => {
  const handleSubmit = (formData) => {
    if (!isLoggedIn) {
      alert('Please log in to submit your ride offer.');
      return false; // not allow to submit
    }

    addRideOffer(formData);
    console.log(formData);
    return true; // allow
  };

  return (
    <>
      <div className="relative w-full mt-14 h-96 shadow-2xl">
        <img
          src="./sharing.jpg"
          alt="carimg"
          className="w-full h-full object-cover"
        />
        <h2 className="absolute top-14 left-1/3 transform -translate-x-1/2 -translate-y-1/2 text-gray-700 text-2xl font-bold bg-white bg-opacity-75 px-4 py-2 rounded">
          Become a Car driver and save on travel costs by sharing your ride with passengers.
        </h2>
      </div>

      {/* Form */}
      <div className="flex flex-col lg:flex-row items-center lg:items-start lg:pl-12 lg:justify-evenly">
        <div className="flex flex-col w-full">
          <OfferRideForm onSubmit={handleSubmit} isLoggedIn={isLoggedIn} />
        </div>
      
      
        {/* Image */}
  <div className='w-full lg:w-2/3 mt-12 lg:mt-32 mx-4 lg:mx-18 lg:order-2 lg:pr-10'>
    <img src="./share.jpg" alt="Share" className='w-full h-auto' />
  </div>
      </div>
        

  

<div className="bg-blue-100 text-gray-700 mt-10 py-20">
  <div className="text-center">
    <h2 className="text-4xl font-semibold">Drive. Share. Save.</h2>
  </div>
  
  <div className="flex flex-col lg:flex-row justify-center lg:space-x-20 space-y-10 lg:space-y-0 mt-12 px-6 lg:px-52">
    <div className="text-center lg:text-left">
      <h3 className="text-lg font-bold">Drive</h3>
      <p className="mt-2">Keep your plans! Hit the road just as you anticipated and make the most of your vehicle’s empty seats.</p>
    </div>

    <div className="text-center lg:text-left">
      <h3 className="text-lg font-bold">Share</h3>
      <p className="mt-2">Travel with good company. Share a memorable ride with travellers from all walks of life.</p>
    </div>

    <div className="text-center lg:text-left">
      <h3 className="text-lg font-bold">Save</h3>
      <p className="mt-2">Tolls, petrol, electricity… Easily divvy up all the costs with other passengers.</p>
    </div>
  </div>
</div>



<div className="flex flex-col lg:flex-row justify-between text-gray-700 mt-10 py-20 px-6 lg:px-32 space-y-10 lg:space-y-0 lg:space-x-10">
  
  <div className="lg:w-1/2 text-center lg:text-left lg:pr-10">
    <h2 className="text-3xl lg:text-4xl font-semibold mb-6">Publish your ride in just a minute</h2>
    <img src="./createride.jpg" alt="ride" className="w-full max-w-xs lg:max-w-none mx-auto lg:mx-0" />
  </div>

  
  <div className="lg:w-1/2 flex flex-col space-y-10 py-10 lg:py-20">
    <div>
      <h3 className="text-lg font-semibold">
        <FontAwesomeIcon icon={faUser} className="pr-2" />
        Create a Carpool account
      </h3>
      <p className="mt-2">Add your profile picture, a few words about you, and your phone number to increase trust between members.</p>
    </div>

    <div>
      <h3 className="text-lg font-semibold">
        <FontAwesomeIcon icon={faCar} className="pr-2" />
        Publish your ride
      </h3>
      <p className="mt-2">Indicate departure and arrival points, the date of the ride, and check our recommended price to increase your chances of getting your first passengers and ratings.</p>
    </div>

    <div>
      <h3 className="text-lg font-semibold">
        <FontAwesomeIcon icon={faBolt} className="pr-2" />
        Accept booking requests
      </h3>
      <p className="mt-2">Review passenger profiles and accept their requests to ride with you. That’s how easy it is to start saving on travel costs!</p>
    </div>
  </div>
</div>


<div className="bg-gray-300 py-28">
  <h2 className="text-center text-3xl font-bold text-gray-800">
    We are here every step of the way
  </h2>

  <div className="flex flex-col lg:flex-row justify-between lg:space-x-12 space-y-10 lg:space-y-0 mt-12 px-6 lg:px-48">
    {/* Service Section */}
    <div className="text-center lg:text-left">
      <FontAwesomeIcon icon={faMessage} className="h-8 w-8 mb-3 text-gray-700" />
      <h3 className="text-lg font-semibold text-gray-700">At your service 24/7</h3>
      <p className="text-sm text-gray-600 mt-2">
        Our team is at your disposal to answer any questions by email or social media. You can also have a live chat directly with experienced members.
      </p>
    </div>

    {/* Support Section */}
    <div className="text-center lg:text-left">
      <FontAwesomeIcon icon={faCar} className="h-8 w-8 mb-3 text-gray-700" />
      <h3 className="text-lg font-semibold text-gray-700">Carpool is at your side</h3>
      <p className="text-sm text-gray-600 mt-2">
        As a driver on our platform, enjoy the peace of mind with enhanced support and safety features when you publish your ride. Connect with trusted passengers and make your journey smoother.
      </p>
    </div>

    {/* Secure Information */}
    <div className="text-center lg:text-left">
      <FontAwesomeIcon icon={faShield} className="h-8 w-8 mb-3 text-gray-700" />
      <h3 className="text-lg font-semibold text-gray-700">100% secure information</h3>
      <p className="text-sm text-gray-600 mt-2">
        Our team is dedicated to the protection of your data, which is always 100% confidential thanks to monitoring tools, secure navigation, and encrypted data.
      </p>
    </div>
  </div>
</div>


  <div className="text-start mt-10 pb-8">
  <h2 className="font-bold text-3xl pt-8 text-gray-700 text-center">Everything you need as a driver, in our Help Centre</h2>

  <div className="flex flex-col lg:flex-row lg:justify-between lg:mx-48 lg:gap-20 mt-12">
    <div className="w-full lg:w-1/2 px-4 lg:px-0">
      <h3 className="font-semibold text-sm text-gray-600">What should I do if there’s an error with my ride?</h3>
      <p className="text-sm text-gray-500 pl-2 mt-2">
      You should edit your ride as soon as you spot the error. If you can’t edit your ride because passengers have already booked, contact them explaining the mistake. If the changes don’t suit them, you should cancel your ride and publish a new one.
      </p>
      <div className="w-auto h-px bg-black mt-8 lg:hidden"></div>
    </div>

    <div className="w-full lg:w-1/2 px-4 lg:px-0 mt-8 lg:mt-0">
      <h3 className="font-semibold text-sm text-gray-600">How do I cancel a carpool ride as a driver of a ride?</h3>
      <p className="text-sm text-gray-500 pl-2 mt-2">
      It only takes a minute to cancel a listed ride. To cancel your listed carpool ride: Go to Your Rides Select the ride you want cancel Click on Your publication Select Cancel your ride Confirm the cancellation
      </p>
    </div>
  </div>

  <div className="flex flex-col lg:flex-row lg:justify-between lg:mx-48 lg:gap-20 mt-10">
    <div className="w-full lg:w-1/2 px-4 lg:px-0">
      <h3 className="font-semibold text-sm text-gray-600">How do I book a carpool ride?</h3>
      <p className="text-sm text-gray-500 pl-2 mt-2">
        You can book a carpool ride on our mobile app, or on carpool.in. Simply search for your destination, choose the date you want to travel and pick the carpool that suits you best! Some rides can be booked instantly, while other rides require manual approval from the driver. Either way, booking a carpool ride is fast, simple and easy.
      </p>
    </div>

    <div className="w-full lg:w-1/2 px-4 lg:px-0 mt-8 lg:mt-0">
      <h3 className="font-semibold text-sm text-gray-600">How do I cancel my carpool ride?</h3>
      <p className="text-sm text-gray-500 pl-2 mt-2">
        If you have a change of plans, you can always cancel your carpool ride from the ‘Your rides’ section of our app. The sooner you cancel, the better. That way the driver has time to accept new passengers. The amount of your refund will depend on how far in advance you cancel. If you cancel more than 24 hours before departure, for example, you’ll receive a full refund, excluding the service fee.
      </p>
    </div>
  </div>
</div>



    
    </>
  );
};

export default Offerride;
