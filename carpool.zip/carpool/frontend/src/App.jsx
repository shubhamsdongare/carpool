import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Offerride from './pages/Offerride';
import Footer from './components/Footer';
import AuthForms from './components/AuthForm';
import Profile from './components/Profile';
import ViewBookedRides from './pages/ViewBookedRides';
import ViewOfferedRides from './pages/ViewOfferedRides';

const App = () => {
  const [rideOffers, setRideOffers] = useState([]);
  const [user, setUser] = useState(null);
  const [bookedRides, setBookedRides] = useState([]);
  const [isProfileVisible, setIsProfileVisible] = useState(false);
  const [offeredRides, setOfferedRides] = useState([]);

  const toggleProfile = () => {
    setIsProfileVisible(!isProfileVisible);
  };

  const addRideOffer = (newOffer) => {
    setRideOffers([...rideOffers, newOffer]);
    setOfferedRides([...offeredRides, newOffer]);
    console.log("Offered Rides:", offeredRides);
  };

  const handleBookRide = (bookingDetails) => {
    if (user) {
      setBookedRides([...bookedRides, bookingDetails]);
    }
  };

  const handleCancelRide = (index) => {
    const updatedRides = bookedRides.filter((_, i) => i !== index);
    setBookedRides(updatedRides);
    alert("Ride canceled successfully!");
  };

  const handleCanceOfferedlRide = (index) => {
    const updatedOffredRides = offeredRides.filter((_, i) => i !== index);
    setOfferedRides(updatedOffredRides);
    alert("Ride canceled successfully!");
  };

  return (
    <Router>
      <Navbar user={user} setUser={setUser} toggleProfile={toggleProfile} />
      {isProfileVisible && (
        <Profile
          user={user}
          setUser={setUser}
          setIsProfileVisible={setIsProfileVisible}
        />
      )}
      <Routes>
        <Route path="/" element={<Home rideOffers={rideOffers} user={user} onBookRide={handleBookRide} />} />
        <Route path="/offer-ride"
               element={<Offerride addRideOffer={addRideOffer} isLoggedIn={!!user} />} />
        <Route path="/auth" element={<AuthForms setUser={setUser} />} />
        <Route path="/view-booked-rides"
               element={<ViewBookedRides bookedRides={bookedRides} onCancelRide={handleCancelRide} />} />
        <Route path="/view-offered-rides"
               element={<ViewOfferedRides offeredRides={offeredRides} onCancelOfferedRide={handleCanceOfferedlRide} />} />
      </Routes>
      <Footer />
    </Router>
  );
};

export default App;
