import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faBars, faTimes, faCirclePlus, faSearch } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';

const Navbar = ({ user, setUser, toggleProfile }) => {
  const Links = [
    { name: "Offer Ride", link: "/offer-ride", icon: faCirclePlus },
    { name: "Search Ride", link: "/", icon: faSearch },
  ];

  const [open, setOpen] = useState(false);

  const toggleMenu = () => setOpen(prevOpen => !prevOpen);

  return (
    <nav className="shadow-md w-full fixed top-0 left-0 z-10">
      <div className="md:flex items-center justify-between bg-white py-4 md:px-10 px-7">
        {/* Logo */}
        <Link to="/" className="font-extrabold text-2xl cursor-pointer text-gray-800">
          Carpool
        </Link>

        {/* Menu Icon for Mobile */}
        <div onClick={toggleMenu} className="text-3xl absolute right-8 top-4 md:hidden cursor-pointer">
          <FontAwesomeIcon icon={open ? faTimes : faBars} />
        </div>

        {/* Links */}
        <ul
          className={`md:flex md:items-center absolute md:static bg-white left-0 w-full md:w-auto transition-all duration-300 ease-in ${
            open ? 'top-16 opacity-100' : 'top-[-490px] opacity-0 md:opacity-100'
          } ml-4 md:ml-0`}
        >
          {Links.map((link) => (
            <li key={link.name} className="md:ml-8 text-xl my-4 md:my-0">
              <Link to={link.link} className="text-gray-800 hover:text-gray-400 flex items-center">
                <FontAwesomeIcon icon={link.icon} className="mr-2" /> {link.name}
              </Link>
            </li>
          ))}

          <li className="md:ml-8 mt-5 md:mt-0">
            {user ? (
              <button onClick={toggleProfile} className="bg-blue-800 text-white py-2 px-5 rounded-3xl hover:bg-blue-500 w-auto font-bold">
                Profile
              </button>
            ) : (
              <Link to="/auth">
                <button className="bg-blue-800 text-white py-2 px-5 rounded-3xl hover:bg-blue-500 w-auto font-bold">
                  Login
                </button>
              </Link>
            )}
          </li>
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
