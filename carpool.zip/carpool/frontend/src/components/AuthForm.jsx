import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios'; // axios for API calls

const AuthForms = ({ setUser }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [tel, setTel] = useState('');
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  // Validate Email Format.....................
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Validate Phone Number......................
  const validatePhone = (tel) => {
    const phoneRegex = /^[0-9]{10}$/; // 10-digit numbers
    return phoneRegex.test(tel);
  };

  // Handle Login Validation........................
  const handleLogin = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!email) newErrors.email = "Email is required.";
    else if (!validateEmail(email)) newErrors.email = "Invalid email format.";
    if (!password) newErrors.password = "Password is required.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/login", { email, password });
      setUser({ name: response.data.name, email, tel: response.data.tel });
      handleCloseForm();
    } catch (error) {
      console.error("Error during login:", error.response?.data || error.message);
      alert("Invalid username or password. Please try again.");
    }
  };

  // Handle Signup Validation......................
  const handleSignup = async (e) => {
    e.preventDefault();
    const newErrors = {};
    if (!name) newErrors.name = "Name is required.";
    if (!tel) newErrors.tel = "Mobile number is required.";
    else if (!validatePhone(tel)) newErrors.tel = "Mobile number must be 10 digits.";
    if (!email) newErrors.email = "Email is required.";
    else if (!validateEmail(email)) newErrors.email = "Invalid email format.";
    if (!password) newErrors.password = "Password is required.";
    else if (password.length < 6) newErrors.password = "Password must be at least 6 characters.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/api/users", { name, tel, email, password });
      alert(response.data.message || "Signup successful! Please log in.");
      setIsLogin(true); // Switch to login form.........
    } catch (error) {
      console.error("Error during signup:", error.response?.data || error.message);
      alert("Signup failed. Please try again.");
    }
  };

  const handleCloseForm = () => {
    navigate('/');
  };

  return (
    <div className="bg-slate-400 p-8 min-h-screen items-center justify-center bg-transparent bg-opacity-50 flex">
      <div className="bg-transparent p-8 rounded shadow-lg max-w-sm w-full">
        {isLogin ? (
          <>
            <h2 className="text-2xl font-bold mb-4">Login</h2>
            <form onSubmit={handleLogin} className="space-y-4">
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
              <button className="bg-blue-800 text-white py-2 px-4 rounded w-full">Login</button>
            </form>
            <p className="mt-4">
              Don't have an account?{' '}
              <span className="text-blue-800 cursor-pointer" onClick={() => setIsLogin(false)}>
                Sign Up
              </span>
            </p>
          </>
        ) : (
          <>
            <h2 className="text-2xl font-bold text-center mb-4">Sign Up</h2>
            <form onSubmit={handleSignup} className="space-y-4">
              <label>Enter your name</label>
              <input
                type="text"
                placeholder="Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
              <label>Enter Mobile Number</label>
              <input
                type="tel"
                placeholder="Mobile"
                value={tel}
                onChange={(e) => setTel(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.tel && <p className="text-red-500 text-sm">{errors.tel}</p>}
              <label>Enter your Email</label>
              <input
                type="email"
                placeholder="Email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
              <label>Enter your Password</label>
              <input
                type="password"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="border p-2 w-full"
                required
              />
              {errors.password && <p className="text-red-500 text-sm">{errors.password}</p>}
              <button className="bg-blue-800 text-white py-2 px-4 rounded w-full">Sign Up</button>
            </form>
            <p className="mt-4">
              Already have an account?{' '}
              <span className="text-blue-800 cursor-pointer" onClick={() => setIsLogin(true)}>
                Login
              </span>
            </p>
          </>
        )}

        <div className="mt-4 text-center">
          <button 
            onClick={handleCloseForm}
            className="bg-gray-500 text-white py-2 px-4 rounded w-full hover:bg-gray-400"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default AuthForms;
