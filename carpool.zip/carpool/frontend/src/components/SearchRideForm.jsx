import React, { useState } from "react";
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarDays, faUser } from '@fortawesome/free-solid-svg-icons';

const SearchRideForm = ({ onSubmit }) => {
  const [formData, setFormData] = useState({
    leavingFrom: '',
    goingTo: '',
    date: '',
    passengers: '1',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevState) => ({
      ...prevState,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.leavingFrom || !formData.goingTo || !formData.date) {
      alert('Please fill out all required fields.');
      return;
    }
    onSubmit(formData);     //passto home

    setFormData({
      leavingFrom: '',
      goingTo: '',
      date: '',
      passengers: '1',
    });
  };

  return (
    <div className="mt-6 flex justify-center items-center px-4 md:px-0">
      <form
        className="w-full max-w-lg lg:max-w-none lg:w-auto shadow-xl border border-gray-400 md:pl-4 lg:rounded-full lg:pl-2 font-medium"
        onSubmit={handleSubmit}
      >
        <div className="flex flex-col lg:flex-row items-center lg:items-center space-y-4 lg:space-y-0 lg:space-x-4">
          {/* Leaving from */}
          <div className="flex items-center space-x-2 w-full lg:w-auto">
            <div className="flex justify-center items-center">
              <div className="w-6 h-6 border-4 border-gray-600 rounded-full flex items-center justify-center"></div>
            </div>
            <input
              type="text"
              name="leavingFrom"
              value={formData.leavingFrom}
              onChange={handleChange}
              placeholder="Leaving from"
              className="w-full lg:w-auto p-2 rounded-lg lg:rounded-s-xl outline-none"
            />
            <div className="hidden lg:block w-px h-10 bg-gray-400 mx-2"></div>
          </div>

          {/* Going to */}
          <div className="flex items-center space-x-2 w-full lg:w-auto">
            <div className="flex justify-center items-center">
              <div className="w-6 h-6 border-4 border-gray-600 rounded-full flex items-center justify-center"></div>
            </div>
            <input
              type="text"
              name="goingTo"
              value={formData.goingTo}
              onChange={handleChange}
              placeholder="Going to"
              className="w-full lg:w-auto p-2 rounded-lg outline-none"
            />
            <div className="hidden lg:block w-px h-10 bg-gray-400 mx-2"></div>
          </div>

          {/* Date */}
          <div className="flex items-center space-x-2 w-full lg:w-auto">
            <FontAwesomeIcon icon={faCalendarDays} className="w-6 h-6" />
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full lg:w-auto p-2 rounded-lg outline-none"
            />
            <div className="hidden lg:block w-px h-10 bg-gray-400 mx-2"></div>
          </div>

          {/* Passengers */}
          <div className="flex items-center space-x-2 w-full lg:w-auto">
            <FontAwesomeIcon icon={faUser} className="w-6 h-6" />
            <input
              type="number"
              name="passengers"
              value={formData.passengers}
              onChange={(e) => {
                const value = Math.max(1, Math.min(6, e.target.value)); // Limit value between 1 and 6
                setFormData((prevState) => ({
                  ...prevState,
                  passengers: value,
                }));
              }}
              placeholder="1 Passenger"
              min="1"
              max="6"
              className="w-full lg:w-auto p-2 rounded-lg outline-none"
            />
          </div>

          {/* Submit */}
          <div className="w-full mt-4 lg:mt-0 lg:w-auto">
            <button
              type="submit"
              className="bg-blue-900 hover:bg-blue-800 text-lg font-bold text-white w-full lg:w-auto px-10 py-4 lg:rounded-r-full"
            >
              Search
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default SearchRideForm;
