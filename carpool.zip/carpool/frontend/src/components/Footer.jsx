import React from 'react'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faTags, faAddressCard, faPaperPlane, faCopyright } from '@fortawesome/free-solid-svg-icons';
import { Link } from 'react-router-dom';

const Footer = () => {
  return (
    <div>
      {/* About */}

      <div className="text-center bg-gray-100 pb-1">
        <div>
        <h2 className="text-center font-bold text-3xl pt-14">About</h2>
        <ul className="flex mt-7 justify-evenly font-semibold mb-12 text-gray-600">
          <a href="">How it work's</a>
          <a href="">About Us</a>
          <a href="">Help Center</a>
          <a href="">Press</a>
        </ul>
        </div>

        <div>
        <button className="bg-blue-500 text-white font-semibold px-8 py-3 rounded-3xl">Language-English(India)</button><br />
        
        <ul className="flex  justify-center mt-7 space-x-9 font-semibold mb-12 text-gray-700">
          <Link href=""><FontAwesomeIcon
            icon={faUser}
            className="w-6 h-6"
          /></Link>
          <a href=""><FontAwesomeIcon
            icon={faUser}
            className="w-6 h-6"
          /></a>
          <a href=""><FontAwesomeIcon
            icon={faUser}
            className="w-6 h-6"
          /></a>
          <a href=""><FontAwesomeIcon
            icon={faUser}
            className="w-6 h-6"
          /></a>
        </ul>
        </div>
      </div>

      <div className="bg-white text-base py-6 flex justify-evenly text-gray-500">
        <h3>Terms and conditions</h3>
        <span>Carpool, 2024 <FontAwesomeIcon
            icon={faCopyright}
            className="w-4 h-4"
          /></span>
      </div>
    </div>
  )
}

export default Footer
