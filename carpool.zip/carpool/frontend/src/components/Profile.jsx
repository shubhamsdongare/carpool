import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Profile = ({ user, setUser, setIsProfileVisible, bookedRides, setBookedRides }) => {
  const navigate = useNavigate();

  
  const [name, setName] = useState(user?.name || "");
  const [email, setEmail] = useState(user?.email || "");
  const [tel, setTel] = useState(user?.tel || "");
  const [hasChanges, setHasChanges] = useState(false);
  const [errors, setErrors] = useState({});

  // if any changes occure
  useEffect(() => {
    if (user) {
      const isDifferent = name !== user.name || email !== user.email || tel !== user.tel;
      setHasChanges(isDifferent);
    }
  }, [name, email, tel, user]);

  // Email
  const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  // Phone Number
  const validatePhone = (tel) => {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(tel);
  };

  const handleLogout = () => {
    setUser(null);
    setIsProfileVisible(false);
    navigate("/");
  };

  const handleViewBookedRides = () => {
    setIsProfileVisible(false);
    navigate("/view-booked-rides");
  };

  const handleViewOfferedRides = () => {
    setIsProfileVisible(false);
    navigate("/view-offered-rides");
  };

  const handleSaveChanges = () => {
    const newErrors = {};
    if (!name) newErrors.name = "Name is required.";
    if (!email) newErrors.email = "Email is required.";
    else if (!validateEmail(email)) newErrors.email = "Invalid email format.";
    if (!tel) newErrors.tel = "Mobile number is required.";
    else if (!validatePhone(tel)) newErrors.tel = "Mobile number must be 10 digits.";

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setUser({ ...user, name, email, tel });
    alert("Profile updated!");
    setHasChanges(false);
    setErrors({});
  };

  const cancelRide = (index) => {
    const updatedRides = bookedRides.filter((_, i) => i !== index);
    setBookedRides(updatedRides);
    alert("Ride canceled successfully!");
    
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
      <div className="bg-white p-8 rounded shadow-lg max-w-md w-full">
        <h2 className="text-2xl font-bold mb-4">User Profile</h2>

        <div className="my-4">
          <label className="block">
            <strong>Name:</strong>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md p-2"
            />
            {errors.name && <p className="text-red-500 text-sm">{errors.name}</p>}
          </label>
        </div>

        <div className="my-4">
          <label className="block">
            <strong>Email:</strong>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md p-2"
            />
            {errors.email && <p className="text-red-500 text-sm">{errors.email}</p>}
          </label>
        </div>

        <div className="my-4">
          <label className="block">
            <strong>Mobile:</strong>
            <input
              type="tel"
              value={tel}
              onChange={(e) => setTel(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md p-2"
            />
            {errors.tel && <p className="text-red-500 text-sm">{errors.tel}</p>}
          </label>
        </div>

        {/* Button to view booked rides */}
        <button onClick={handleViewBookedRides} className="my-4 font-bold flex justify-between w-full">
          View Booked Rides <span>{">"}</span>
        </button>

        <button onClick={handleViewOfferedRides} className="my-4 font-bold flex justify-between w-full">
          View Offered Rides <span>{">"}</span>
        </button>

        {/* save Changes button only show if there are changes */}
        {hasChanges && (
          <button
            onClick={handleSaveChanges}
            className="bg-blue-600 text-white py-2 px-4 rounded w-full hover:bg-blue-500 mb-2"
          >
            Save Changes
          </button>
        )}

        <button
          onClick={handleLogout}
          className="bg-red-600 text-white py-2 px-4 rounded w-full hover:bg-red-500"
        >
          Logout
        </button>

        <button
          onClick={() => setIsProfileVisible(false)}
          className="mt-4 flex text-gray-500 hover:text-gray-700 w-full justify-center"
        >
          Close
        </button>
      </div>
    </div>
  );
};

export default Profile;
