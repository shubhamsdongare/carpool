import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const BookingForm = ({ ride, onConfirm }) => {
  const navigate = useNavigate();
  const [userName, setUserName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('cash'); // Default payment method is cash
  const [numPassengers, setNumPassengers] = useState(1); // Default to 1 passenger

  const handleSubmit = (e) => {
    e.preventDefault();

    onConfirm({ ride, userName, paymentMethod, numPassengers });

    navigate('/');
  };

  return (
    <div className="modal-content p-4 bg-white rounded shadow-lg">
      <h2 className="text-xl font-bold mb-4">Book Ride</h2>
      <form onSubmit={handleSubmit} className="booking-form">
        <div className="mb-4">
          <label className="block text-gray-700">
            Pick-up Location: <strong>{ride.pickup}</strong>
          </label>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">
            Drop Location: <strong>{ride.drop}</strong>
          </label>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">
            Date: <strong>{ride.date}</strong>
          </label>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">
            Time: <strong>{ride.time}</strong>
          </label>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">
            Passengers: <strong>{ride.passengers}</strong>
          </label>
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">User Name:</label>
          <input
            type="text"
            value={userName}
            onChange={(e) => setUserName(e.target.value)}
            required
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          />
        </div>
        <div className="mb-4">
          <label className="block text-gray-700">Number of Passengers:</label>
          <input
            type="number"
            value={numPassengers}
            onChange={(e) => setNumPassengers(Math.max(1, e.target.value))}
            min="1"
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          />
        </div>

        <div className="mb-4">
          <label className="block text-gray-700">Payment Method:</label>
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            className="mt-1 block w-full border border-gray-300 rounded-md p-2"
          >
            <option value="cash">Cash</option>
            <option value="credit">Credit Card</option>
            <option value="paypal">PayPal</option>
          </select>
        </div>
        
        <button
          type="submit"
          className="bg-green-600 hover:bg-green-500 text-white font-bold py-2 px-4 rounded mt-4"
        >
          Confirm Booking
        </button>
      </form>
    </div>
  );
};

export default BookingForm;
