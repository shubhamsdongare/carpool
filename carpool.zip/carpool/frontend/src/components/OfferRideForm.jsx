import React, { useState } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faCalendarDays, faClock } from '@fortawesome/free-solid-svg-icons';

const OfferRideForm = ({ onSubmit }) => {
  const [numPassengers, setNumPassengers] = useState('1');
  const [availableSeats, setAvailableSeats] = useState(1);
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [pickUp, setPickUp] = useState('');
  const [dropLocation, setDropLocation] = useState('');
  const [carName, setCarName] = useState('');
  const [stops, setStops] = useState([{ location: '' }]);

  const handleAddStop = () => setStops([...stops, { location: '' }]);

  const handleRemoveStop = (index) => {
    setStops(stops.filter((_, i) => i !== index));
  };

  const handleStopChange = (index, value) => {
    setStops(stops.map((stop, i) => (i === index ? { location: value } : stop)));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const newRideOffer = {
      pickup: pickUp,
      drop: dropLocation,
      passengers: numPassengers,
      availableSeats: availableSeats,
      date: date,
      time: time,
      carName: carName,
      stops: stops,
    };

    const isAllowed = onSubmit(newRideOffer); // onSubmit handler

    if (isAllowed) {
      setPickUp('');
      setDropLocation('');
      setDate('');
      setTime('');
      setNumPassengers('1');
      setAvailableSeats(1);
      setCarName('');
      setStops([{ location: '' }]);
    }
  };

  return (
    <div className="w-full lg:w-3/5 p-6 border border-gray-300 rounded-lg shadow-lg mt-6 lg:mt-8 mx-8 lg:order-1">
      <h2 className="text-2xl font-bold mb-4 text-center text-gray-500">Offer a Ride</h2>
      <form onSubmit={handleSubmit}>
        {/* Pick-Up Location */}
        <div className="mb-4">
          <label htmlFor="pick-up" className="block text-sm font-medium text-gray-800">Pick Up Location</label>
          <div className="flex items-center pl-2 mt-1 border rounded-lg">
            <div className="w-5 h-5 border-4 border-gray-600 rounded-full flex items-center justify-center"></div>
            <input
              id="pick-up"
              type="text"
              placeholder="Pick Up From"
              value={pickUp}
              onChange={(e) => setPickUp(e.target.value)}
              className="ml-2 p-2 w-full outline-none"
              required
            />
          </div>
        </div>

        {/* Drop Location */}
        <div className="mb-4">
          <label htmlFor="drop-location" className="block text-sm font-medium text-gray-800">Drop Location</label>
          <div className="flex items-center pl-2 mt-1 border rounded-lg">
            <div className="w-5 h-5 border-4 border-gray-600 rounded-full flex items-center justify-center"></div>
            <input
              id="drop-location"
              type="text"
              placeholder="Drop to"
              value={dropLocation}
              onChange={(e) => setDropLocation(e.target.value)}
              className="ml-2 p-2 w-full outline-none"
              required
            />
          </div>
        </div>

        {/* Number of Passengers */}
        <div className="mb-4 my-6">
          <label htmlFor="num-passengers" className="block text-sm font-medium text-gray-700">Number of Passengers</label>
          <select
            id="num-passengers"
            value={numPassengers}
            onChange={(e) => {
              setNumPassengers(e.target.value);
              setAvailableSeats(e.target.value);
            }}
            className="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
          >
            {[1, 2, 3, 4, 5, 6].map((num) => (
              <option key={num} value={num}>{num}</option>
            ))}
          </select>
        </div>

        {/* Date and Time */}
        <div className="mb-4">
          <label htmlFor="date" className="block text-sm font-medium text-gray-700">Date & Time</label>
          <div className="flex flex-col lg:flex-row gap-4">
            <div className="flex py-2 px-1 border rounded-md w-full lg:w-1/2">
              <FontAwesomeIcon icon={faCalendarDays} className="w-5 h-5 mt-1" />
              <input
                type="date"
                id="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="mt-1 ml-4 block w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>
            <div className="flex py-2 px-1 border rounded-md w-full lg:w-1/2">
              <FontAwesomeIcon icon={faClock} className="w-5 h-5 mt-1" />
              <input
                type="time"
                id="time"
                value={time}
                onChange={(e) => setTime(e.target.value)}
                className="mt-1 ml-4 block w-full border-gray-300 rounded-lg shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                required
              />
            </div>
          </div>
        </div>

        {/* Car Name */}
        <div className="mb-4">
          <label htmlFor="car-name" className="block text-sm font-medium text-gray-700">Car Name</label>
          <input
            type="text"
            id="car-name"
            value={carName}
            onChange={(e) => setCarName(e.target.value)}
            className="mt-1 block w-full text-sm text-gray-500 border-gray-500 bg-gray-200 rounded-lg py-2"
            required
          />
        </div>

        {/* Stops */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700">Add stopovers to get more passengers</label>
          {stops.map((stop, index) => (
            <div key={index} className="flex items-center mb-2">
              <input
                type="text"
                value={stop.location}
                onChange={(e) => handleStopChange(index, e.target.value)}
                placeholder={`Stop ${index + 1}`}
                className="p-2 w-full border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
              />
              <button
                type="button"
                onClick={() => handleRemoveStop(index)}
                className="ml-2 bg-red-500 hover:bg-red-600 text-white font-bold py-1 px-3 rounded"
              >
                Remove
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={handleAddStop}
            className="w-1/4 bg-blue-500 hover:bg-blue-600 text-white font-bold py-1 px-4 rounded"
          >
            Add Stop
          </button>
        </div>

        {/* Submit */}
        <div className="flex justify-center">
          <button
            type="submit"
            className="w-1/3 bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded"
          >
            Submit
          </button>
        </div>
      </form>
    </div>
  );
};

export default OfferRideForm;
